﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASEASSIGNMENT
{
    public enum Action
    {
      
        Circle,
        Square,
        Rectangle,
        Triangle,
        Line,
        Move,
        Clear,
        Reset,
        None
    }
}
